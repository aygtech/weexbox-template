// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 19);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n/*\n * @Author: remi.zhang\n * @Date: 2018-12-11 11:04:31\n * @Last Modified by: remi.zhang\n * @Last Modified time: 2019-01-23 14:54:16\n */\n// const modal = weex.requireModule('wb-modal')\n// const _network = weex.requireModule('wb-network')\nvar _router = weex.requireModule('wb-router');\n// const _location = weex.requireModule('wb-location')\n\nvar env = weex.config.env;\n\n\nvar domain = 'https://weexbox.surge.sh';\nvar examplesWeex = 'https://raw.githubusercontent.com/aygtech/incubator-weex/master/ios/playground/bundlejs/examples2.weex.js';\nvar now = new Date().getTime();\nvar end = new Date('2019/02/3 12:00:00').getTime();\nif (now >= end) {\n  domain = 'https://aygtech.github.io/weexbox';\n  examplesWeex = 'https://raw.githubusercontent.com/aygtech/incubator-weex/master/ios/playground/bundlejs/examples.weex.js';\n}\n// weexbox 域名地址\nvar weexBoxDomain = exports.weexBoxDomain = domain;\n// weexbox module域名地址\nvar weexBoxUrl = exports.weexBoxUrl = domain + '/guide/module.html';\n\n/**\n * 屏幕高度\n */\nvar screenHeight = exports.screenHeight = function screenHeight() {\n  var height = env.deviceHeight / env.deviceWidth * 750;\n  return Math.ceil(height);\n};\n\n// 页面路由\nvar router = exports.router = {\n  /**\n   * 打开页面\n   * @param {object} option - 参数\n   * @param {string} option.url - 下一个weex/web的路径\n   * @param {string} [option.name] - 页面名称。内置\"weex\"、\"web\"，其他路由需要原生先注册\n   * @param {string} [option.type=push] - 下一个weex/web的路径\n   * @param {boolean} [option.navBarHidden=false] - 是否隐藏导航栏\n   * @param {object} [option.params={}] - // 需要传到下一个页面的数据\n   */\n  open: function open(option) {\n    var _option = {\n      name: 'weex',\n      url: null,\n      type: 'push',\n      navBarHidden: false,\n      params: {}\n    };\n    var param = Object.assign(_option, option);\n    _router.open(param);\n  },\n\n  /**\n   * 关闭页面\n   * @param {string} [level=1] - 关闭页面的级数\n   */\n  close: function close() {\n    var level = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;\n\n    _router.close(level);\n  },\n\n  /**\n   * 刷新weex页面\n   */\n  refresh: function refresh() {\n    _router.refresh();\n  },\n\n  /**\n   * 获取页面参数\n   */\n  getParams: function getParams() {\n    return _router.getParams();\n  }\n};\n\nexports.default = {\n  weexBoxDomain: weexBoxDomain,\n  weexBoxUrl: weexBoxUrl,\n  router: router,\n  screenHeight: screenHeight,\n  examplesWeex: examplesWeex\n};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvbmF0aXZlLmpzPzY5OGEiXSwibmFtZXMiOlsiX3JvdXRlciIsIndlZXgiLCJyZXF1aXJlTW9kdWxlIiwiZW52IiwiY29uZmlnIiwiZG9tYWluIiwiZXhhbXBsZXNXZWV4Iiwibm93IiwiRGF0ZSIsImdldFRpbWUiLCJlbmQiLCJ3ZWV4Qm94RG9tYWluIiwid2VleEJveFVybCIsInNjcmVlbkhlaWdodCIsImhlaWdodCIsImRldmljZUhlaWdodCIsImRldmljZVdpZHRoIiwiTWF0aCIsImNlaWwiLCJyb3V0ZXIiLCJvcGVuIiwib3B0aW9uIiwiX29wdGlvbiIsIm5hbWUiLCJ1cmwiLCJ0eXBlIiwibmF2QmFySGlkZGVuIiwicGFyYW1zIiwicGFyYW0iLCJPYmplY3QiLCJhc3NpZ24iLCJjbG9zZSIsImxldmVsIiwicmVmcmVzaCIsImdldFBhcmFtcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQTs7Ozs7O0FBTUE7QUFDQTtBQUNBLElBQU1BLFVBQVVDLEtBQUtDLGFBQUwsQ0FBbUIsV0FBbkIsQ0FBaEI7QUFDQTs7SUFFUUMsRyxHQUFRRixLQUFLRyxNLENBQWJELEc7OztBQUVSLElBQUlFLFNBQVMsMEJBQWI7QUFDQSxJQUFJQyxlQUFlLDJHQUFuQjtBQUNBLElBQU1DLE1BQU0sSUFBSUMsSUFBSixHQUFXQyxPQUFYLEVBQVo7QUFDQSxJQUFNQyxNQUFNLElBQUlGLElBQUosQ0FBUyxvQkFBVCxFQUErQkMsT0FBL0IsRUFBWjtBQUNBLElBQUlGLE9BQU9HLEdBQVgsRUFBZ0I7QUFDZEwsV0FBUyxtQ0FBVDtBQUNBQyxpQkFBZSwwR0FBZjtBQUNEO0FBQ0Q7QUFDTyxJQUFNSyx3Q0FBZ0JOLE1BQXRCO0FBQ1A7QUFDTyxJQUFNTyxrQ0FBZ0JQLE1BQWhCLHVCQUFOOztBQUVQOzs7QUFHTyxJQUFNUSxzQ0FBZSxTQUFmQSxZQUFlLEdBQU07QUFDaEMsTUFBTUMsU0FBU1gsSUFBSVksWUFBSixHQUFtQlosSUFBSWEsV0FBdkIsR0FBcUMsR0FBcEQ7QUFDQSxTQUFPQyxLQUFLQyxJQUFMLENBQVVKLE1BQVYsQ0FBUDtBQUNELENBSE07O0FBS1A7QUFDTyxJQUFNSywwQkFBUztBQUNwQjs7Ozs7Ozs7O0FBU0FDLE1BVm9CLGdCQVVmQyxNQVZlLEVBVVA7QUFDWCxRQUFNQyxVQUFVO0FBQ2RDLFlBQU0sTUFEUTtBQUVkQyxXQUFLLElBRlM7QUFHZEMsWUFBTSxNQUhRO0FBSWRDLG9CQUFjLEtBSkE7QUFLZEMsY0FBUTtBQUxNLEtBQWhCO0FBT0EsUUFBTUMsUUFBUUMsT0FBT0MsTUFBUCxDQUFjUixPQUFkLEVBQXVCRCxNQUF2QixDQUFkO0FBQ0FyQixZQUFRb0IsSUFBUixDQUFhUSxLQUFiO0FBQ0QsR0FwQm1COztBQXFCcEI7Ozs7QUFJQUcsT0F6Qm9CLG1CQXlCSDtBQUFBLFFBQVhDLEtBQVcsdUVBQUgsQ0FBRzs7QUFDZmhDLFlBQVErQixLQUFSLENBQWNDLEtBQWQ7QUFDRCxHQTNCbUI7O0FBNEJwQjs7O0FBR0FDLFNBL0JvQixxQkErQlY7QUFDUmpDLFlBQVFpQyxPQUFSO0FBQ0QsR0FqQ21COztBQWtDcEI7OztBQUdBQyxXQXJDb0IsdUJBcUNSO0FBQ1YsV0FBT2xDLFFBQVFrQyxTQUFSLEVBQVA7QUFDRDtBQXZDbUIsQ0FBZjs7a0JBMENRO0FBQ2J2Qiw4QkFEYTtBQUViQyx3QkFGYTtBQUdiTyxnQkFIYTtBQUliTiw0QkFKYTtBQUtiUDtBQUxhLEMiLCJmaWxlIjoiNS5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBAQXV0aG9yOiByZW1pLnpoYW5nXG4gKiBARGF0ZTogMjAxOC0xMi0xMSAxMTowNDozMVxuICogQExhc3QgTW9kaWZpZWQgYnk6IHJlbWkuemhhbmdcbiAqIEBMYXN0IE1vZGlmaWVkIHRpbWU6IDIwMTktMDEtMjMgMTQ6NTQ6MTZcbiAqL1xuLy8gY29uc3QgbW9kYWwgPSB3ZWV4LnJlcXVpcmVNb2R1bGUoJ3diLW1vZGFsJylcbi8vIGNvbnN0IF9uZXR3b3JrID0gd2VleC5yZXF1aXJlTW9kdWxlKCd3Yi1uZXR3b3JrJylcbmNvbnN0IF9yb3V0ZXIgPSB3ZWV4LnJlcXVpcmVNb2R1bGUoJ3diLXJvdXRlcicpXG4vLyBjb25zdCBfbG9jYXRpb24gPSB3ZWV4LnJlcXVpcmVNb2R1bGUoJ3diLWxvY2F0aW9uJylcblxuY29uc3QgeyBlbnYgfSA9IHdlZXguY29uZmlnXG5cbmxldCBkb21haW4gPSAnaHR0cHM6Ly93ZWV4Ym94LnN1cmdlLnNoJ1xubGV0IGV4YW1wbGVzV2VleCA9ICdodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vYXlndGVjaC9pbmN1YmF0b3Itd2VleC9tYXN0ZXIvaW9zL3BsYXlncm91bmQvYnVuZGxlanMvZXhhbXBsZXMyLndlZXguanMnXG5jb25zdCBub3cgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKVxuY29uc3QgZW5kID0gbmV3IERhdGUoJzIwMTkvMDIvMyAxMjowMDowMCcpLmdldFRpbWUoKVxuaWYgKG5vdyA+PSBlbmQpIHtcbiAgZG9tYWluID0gJ2h0dHBzOi8vYXlndGVjaC5naXRodWIuaW8vd2VleGJveCdcbiAgZXhhbXBsZXNXZWV4ID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbS9heWd0ZWNoL2luY3ViYXRvci13ZWV4L21hc3Rlci9pb3MvcGxheWdyb3VuZC9idW5kbGVqcy9leGFtcGxlcy53ZWV4LmpzJ1xufVxuLy8gd2VleGJveCDln5/lkI3lnLDlnYBcbmV4cG9ydCBjb25zdCB3ZWV4Qm94RG9tYWluID0gZG9tYWluXG4vLyB3ZWV4Ym94IG1vZHVsZeWfn+WQjeWcsOWdgFxuZXhwb3J0IGNvbnN0IHdlZXhCb3hVcmwgPSBgJHtkb21haW59L2d1aWRlL21vZHVsZS5odG1sYFxuXG4vKipcbiAqIOWxj+W5lemrmOW6plxuICovXG5leHBvcnQgY29uc3Qgc2NyZWVuSGVpZ2h0ID0gKCkgPT4ge1xuICBjb25zdCBoZWlnaHQgPSBlbnYuZGV2aWNlSGVpZ2h0IC8gZW52LmRldmljZVdpZHRoICogNzUwXG4gIHJldHVybiBNYXRoLmNlaWwoaGVpZ2h0KVxufVxuXG4vLyDpobXpnaLot6/nlLFcbmV4cG9ydCBjb25zdCByb3V0ZXIgPSB7XG4gIC8qKlxuICAgKiDmiZPlvIDpobXpnaJcbiAgICogQHBhcmFtIHtvYmplY3R9IG9wdGlvbiAtIOWPguaVsFxuICAgKiBAcGFyYW0ge3N0cmluZ30gb3B0aW9uLnVybCAtIOS4i+S4gOS4qndlZXgvd2Vi55qE6Lev5b6EXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9uLm5hbWVdIC0g6aG16Z2i5ZCN56ew44CC5YaF572uXCJ3ZWV4XCLjgIFcIndlYlwi77yM5YW25LuW6Lev55Sx6ZyA6KaB5Y6f55Sf5YWI5rOo5YaMXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbb3B0aW9uLnR5cGU9cHVzaF0gLSDkuIvkuIDkuKp3ZWV4L3dlYueahOi3r+W+hFxuICAgKiBAcGFyYW0ge2Jvb2xlYW59IFtvcHRpb24ubmF2QmFySGlkZGVuPWZhbHNlXSAtIOaYr+WQpumakOiXj+WvvOiIquagj1xuICAgKiBAcGFyYW0ge29iamVjdH0gW29wdGlvbi5wYXJhbXM9e31dIC0gLy8g6ZyA6KaB5Lyg5Yiw5LiL5LiA5Liq6aG16Z2i55qE5pWw5o2uXG4gICAqL1xuICBvcGVuKG9wdGlvbikge1xuICAgIGNvbnN0IF9vcHRpb24gPSB7XG4gICAgICBuYW1lOiAnd2VleCcsXG4gICAgICB1cmw6IG51bGwsXG4gICAgICB0eXBlOiAncHVzaCcsXG4gICAgICBuYXZCYXJIaWRkZW46IGZhbHNlLFxuICAgICAgcGFyYW1zOiB7fSxcbiAgICB9XG4gICAgY29uc3QgcGFyYW0gPSBPYmplY3QuYXNzaWduKF9vcHRpb24sIG9wdGlvbilcbiAgICBfcm91dGVyLm9wZW4ocGFyYW0pXG4gIH0sXG4gIC8qKlxuICAgKiDlhbPpl63pobXpnaJcbiAgICogQHBhcmFtIHtzdHJpbmd9IFtsZXZlbD0xXSAtIOWFs+mXremhtemdoueahOe6p+aVsFxuICAgKi9cbiAgY2xvc2UobGV2ZWwgPSAxKSB7XG4gICAgX3JvdXRlci5jbG9zZShsZXZlbClcbiAgfSxcbiAgLyoqXG4gICAqIOWIt+aWsHdlZXjpobXpnaJcbiAgICovXG4gIHJlZnJlc2goKSB7XG4gICAgX3JvdXRlci5yZWZyZXNoKClcbiAgfSxcbiAgLyoqXG4gICAqIOiOt+WPlumhtemdouWPguaVsFxuICAgKi9cbiAgZ2V0UGFyYW1zKCkge1xuICAgIHJldHVybiBfcm91dGVyLmdldFBhcmFtcygpXG4gIH0sXG59XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgd2VleEJveERvbWFpbixcbiAgd2VleEJveFVybCxcbiAgcm91dGVyLFxuICBzY3JlZW5IZWlnaHQsXG4gIGV4YW1wbGVzV2VleCxcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///5\n");

/***/ }),
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(20);


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar _App = __webpack_require__(21);\n\nvar _App2 = _interopRequireDefault(_App);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\n_App2.default.el = '#root';\nnew Vue(_App2.default);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcGFnZS9tb2R1bGUvaW5kZXguanM/OGM2OSJdLCJuYW1lcyI6WyJBcHAiLCJlbCIsIlZ1ZSJdLCJtYXBwaW5ncyI6Ijs7QUFBQTs7Ozs7O0FBRUFBLGNBQUlDLEVBQUosR0FBUyxPQUFUO0FBQ0EsSUFBSUMsR0FBSixDQUFRRixhQUFSIiwiZmlsZSI6IjIwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEFwcCBmcm9tICcuL0FwcC52dWUnXG5cbkFwcC5lbCA9ICcjcm9vdCdcbm5ldyBWdWUoQXBwKVxuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///20\n");

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

eval("var __vue_exports__, __vue_options__\nvar __vue_styles__ = []\n\n/* styles */\n__vue_styles__.push(__webpack_require__(22)\n)\n\n/* script */\n__vue_exports__ = __webpack_require__(23)\n\n/* template */\nvar __vue_template__ = __webpack_require__(25)\n__vue_options__ = __vue_exports__ = __vue_exports__ || {}\nif (\n  typeof __vue_exports__.default === \"object\" ||\n  typeof __vue_exports__.default === \"function\"\n) {\nif (Object.keys(__vue_exports__).some(function (key) { return key !== \"default\" && key !== \"__esModule\" })) {console.error(\"named exports are not supported in *.vue files.\")}\n__vue_options__ = __vue_exports__ = __vue_exports__.default\n}\nif (typeof __vue_options__ === \"function\") {\n  __vue_options__ = __vue_options__.options\n}\n__vue_options__.__file = \"/Users/mario/Documents/aygtech/weexbox-template/src/page/module/App.vue\"\n__vue_options__.render = __vue_template__.render\n__vue_options__.staticRenderFns = __vue_template__.staticRenderFns\n__vue_options__._scopeId = \"data-v-0dadf195\"\n__vue_options__.style = __vue_options__.style || {}\n__vue_styles__.forEach(function (module) {\n  for (var name in module) {\n    __vue_options__.style[name] = module[name]\n  }\n})\nif (typeof __register_static_styles__ === \"function\") {\n  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)\n}\n\nmodule.exports = __vue_exports__\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcGFnZS9tb2R1bGUvQXBwLnZ1ZT9hMTU4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7O0FBRUE7QUFDQSxvQkFBb0IsbUJBQU8sQ0FBQyxFQUF5UDtBQUNyUjs7QUFFQTtBQUNBLGtCQUFrQixtQkFBTyxDQUFDLEVBQXlKOztBQUVuTDtBQUNBLHVCQUF1QixtQkFBTyxDQUFDLEVBQXFLO0FBQ3BNO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzREFBc0QsbURBQW1ELElBQUk7QUFDN0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7O0FBRUEiLCJmaWxlIjoiMjEuanMiLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgX192dWVfZXhwb3J0c19fLCBfX3Z1ZV9vcHRpb25zX19cbnZhciBfX3Z1ZV9zdHlsZXNfXyA9IFtdXG5cbi8qIHN0eWxlcyAqL1xuX192dWVfc3R5bGVzX18ucHVzaChyZXF1aXJlKFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvd2VleC12dWUtbG9hZGVyL2xpYi9zdHlsZS1sb2FkZXIhc2Fzcy1sb2FkZXI/e1xcXCJzb3VyY2VNYXBcXFwiOmZhbHNlfSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvd2VleC12dWUtbG9hZGVyL2xpYi9zdHlsZS1yZXdyaXRlcj9pZD1kYXRhLXYtMGRhZGYxOTUhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3dlZXgtdnVlLWxvYWRlci9saWIvc2VsZWN0b3I/dHlwZT1zdHlsZXMmaW5kZXg9MCEuL0FwcC52dWVcIilcbilcblxuLyogc2NyaXB0ICovXG5fX3Z1ZV9leHBvcnRzX18gPSByZXF1aXJlKFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvd2VleC12dWUtbG9hZGVyL2xpYi9zY3JpcHQtbG9hZGVyIWJhYmVsLWxvYWRlciEuLi8uLi8uLi9ub2RlX21vZHVsZXMvd2VleC12dWUtbG9hZGVyL2xpYi9zZWxlY3Rvcj90eXBlPXNjcmlwdCZpbmRleD0wIS4vQXBwLnZ1ZVwiKVxuXG4vKiB0ZW1wbGF0ZSAqL1xudmFyIF9fdnVlX3RlbXBsYXRlX18gPSByZXF1aXJlKFwiISEuLi8uLi8uLi9ub2RlX21vZHVsZXMvd2VleC12dWUtbG9hZGVyL2xpYi90ZW1wbGF0ZS1jb21waWxlcj9pZD1kYXRhLXYtMGRhZGYxOTUhLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3dlZXgtdnVlLWxvYWRlci9saWIvc2VsZWN0b3I/dHlwZT10ZW1wbGF0ZSZpbmRleD0wIS4vQXBwLnZ1ZVwiKVxuX192dWVfb3B0aW9uc19fID0gX192dWVfZXhwb3J0c19fID0gX192dWVfZXhwb3J0c19fIHx8IHt9XG5pZiAoXG4gIHR5cGVvZiBfX3Z1ZV9leHBvcnRzX18uZGVmYXVsdCA9PT0gXCJvYmplY3RcIiB8fFxuICB0eXBlb2YgX192dWVfZXhwb3J0c19fLmRlZmF1bHQgPT09IFwiZnVuY3Rpb25cIlxuKSB7XG5pZiAoT2JqZWN0LmtleXMoX192dWVfZXhwb3J0c19fKS5zb21lKGZ1bmN0aW9uIChrZXkpIHsgcmV0dXJuIGtleSAhPT0gXCJkZWZhdWx0XCIgJiYga2V5ICE9PSBcIl9fZXNNb2R1bGVcIiB9KSkge2NvbnNvbGUuZXJyb3IoXCJuYW1lZCBleHBvcnRzIGFyZSBub3Qgc3VwcG9ydGVkIGluICoudnVlIGZpbGVzLlwiKX1cbl9fdnVlX29wdGlvbnNfXyA9IF9fdnVlX2V4cG9ydHNfXyA9IF9fdnVlX2V4cG9ydHNfXy5kZWZhdWx0XG59XG5pZiAodHlwZW9mIF9fdnVlX29wdGlvbnNfXyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gIF9fdnVlX29wdGlvbnNfXyA9IF9fdnVlX29wdGlvbnNfXy5vcHRpb25zXG59XG5fX3Z1ZV9vcHRpb25zX18uX19maWxlID0gXCIvVXNlcnMvbWFyaW8vRG9jdW1lbnRzL2F5Z3RlY2gvd2VleGJveC10ZW1wbGF0ZS9zcmMvcGFnZS9tb2R1bGUvQXBwLnZ1ZVwiXG5fX3Z1ZV9vcHRpb25zX18ucmVuZGVyID0gX192dWVfdGVtcGxhdGVfXy5yZW5kZXJcbl9fdnVlX29wdGlvbnNfXy5zdGF0aWNSZW5kZXJGbnMgPSBfX3Z1ZV90ZW1wbGF0ZV9fLnN0YXRpY1JlbmRlckZuc1xuX192dWVfb3B0aW9uc19fLl9zY29wZUlkID0gXCJkYXRhLXYtMGRhZGYxOTVcIlxuX192dWVfb3B0aW9uc19fLnN0eWxlID0gX192dWVfb3B0aW9uc19fLnN0eWxlIHx8IHt9XG5fX3Z1ZV9zdHlsZXNfXy5mb3JFYWNoKGZ1bmN0aW9uIChtb2R1bGUpIHtcbiAgZm9yICh2YXIgbmFtZSBpbiBtb2R1bGUpIHtcbiAgICBfX3Z1ZV9vcHRpb25zX18uc3R5bGVbbmFtZV0gPSBtb2R1bGVbbmFtZV1cbiAgfVxufSlcbmlmICh0eXBlb2YgX19yZWdpc3Rlcl9zdGF0aWNfc3R5bGVzX18gPT09IFwiZnVuY3Rpb25cIikge1xuICBfX3JlZ2lzdGVyX3N0YXRpY19zdHlsZXNfXyhfX3Z1ZV9vcHRpb25zX18uX3Njb3BlSWQsIF9fdnVlX3N0eWxlc19fKVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9fdnVlX2V4cG9ydHNfX1xuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///21\n");

/***/ }),
/* 22 */
/***/ (function(module, exports) {

eval("module.exports = {\n  \"item\": {\n    \"fontSize\": \"34\",\n    \"paddingTop\": \"30\",\n    \"paddingRight\": \"30\",\n    \"paddingBottom\": \"30\",\n    \"paddingLeft\": \"30\",\n    \"borderBottomColor\": \"#e7e5e5\",\n    \"borderBottomWidth\": \"1\"\n  }\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcGFnZS9tb2R1bGUvQXBwLnZ1ZT9lMmZmIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiMjIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHtcbiAgXCJpdGVtXCI6IHtcbiAgICBcImZvbnRTaXplXCI6IFwiMzRcIixcbiAgICBcInBhZGRpbmdUb3BcIjogXCIzMFwiLFxuICAgIFwicGFkZGluZ1JpZ2h0XCI6IFwiMzBcIixcbiAgICBcInBhZGRpbmdCb3R0b21cIjogXCIzMFwiLFxuICAgIFwicGFkZGluZ0xlZnRcIjogXCIzMFwiLFxuICAgIFwiYm9yZGVyQm90dG9tQ29sb3JcIjogXCIjZTdlNWU1XCIsXG4gICAgXCJib3JkZXJCb3R0b21XaWR0aFwiOiBcIjFcIlxuICB9XG59Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///22\n");

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar _native = __webpack_require__(5);\n\nvar _moduleList = __webpack_require__(24);\n\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n\nvar navigator = weex.requireModule('wb-navigator');\n\nexports.default = {\n  components: {},\n  data: function data() {\n    return {\n      moduleList: _moduleList.moduleList\n    };\n  },\n  created: function created() {\n    navigator.setCenterItem({\n      text: 'WeexBox例子',\n      color: '3d3d3d'\n    }, function () {});\n  },\n\n  methods: {\n    detail: function detail(item) {\n      _native.router.open({\n        url: 'page/' + item + '.js',\n        params: {\n          title: item,\n          url: item\n        }\n      });\n    }\n  }\n};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcGFnZS9tb2R1bGUvQXBwLnZ1ZT85ZmRhIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFhOztBQUViO0FBQ0E7QUFDQSxDQUFDOztBQUVELGNBQWMsbUJBQU8sQ0FBQyxDQUFvQjs7QUFFMUMsa0JBQWtCLG1CQUFPLENBQUMsRUFBd0I7O0FBRWxEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSyxnQkFBZ0I7QUFDckIsR0FBRzs7QUFFSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSIsImZpbGUiOiIyMy5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0JztcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gIHZhbHVlOiB0cnVlXG59KTtcblxudmFyIF9uYXRpdmUgPSByZXF1aXJlKCcuLi8uLi91dGlscy9uYXRpdmUnKTtcblxudmFyIF9tb2R1bGVMaXN0ID0gcmVxdWlyZSgnLi4vLi4vdXRpbHMvbW9kdWxlTGlzdCcpO1xuXG4vL1xuLy9cbi8vXG4vL1xuLy9cbi8vXG4vL1xuLy9cbi8vXG4vL1xuLy9cbi8vXG4vL1xuXG52YXIgbmF2aWdhdG9yID0gd2VleC5yZXF1aXJlTW9kdWxlKCd3Yi1uYXZpZ2F0b3InKTtcblxuZXhwb3J0cy5kZWZhdWx0ID0ge1xuICBjb21wb25lbnRzOiB7fSxcbiAgZGF0YTogZnVuY3Rpb24gZGF0YSgpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbW9kdWxlTGlzdDogX21vZHVsZUxpc3QubW9kdWxlTGlzdFxuICAgIH07XG4gIH0sXG4gIGNyZWF0ZWQ6IGZ1bmN0aW9uIGNyZWF0ZWQoKSB7XG4gICAgbmF2aWdhdG9yLnNldENlbnRlckl0ZW0oe1xuICAgICAgdGV4dDogJ1dlZXhCb3jkvovlrZAnLFxuICAgICAgY29sb3I6ICczZDNkM2QnXG4gICAgfSwgZnVuY3Rpb24gKCkge30pO1xuICB9LFxuXG4gIG1ldGhvZHM6IHtcbiAgICBkZXRhaWw6IGZ1bmN0aW9uIGRldGFpbChpdGVtKSB7XG4gICAgICBfbmF0aXZlLnJvdXRlci5vcGVuKHtcbiAgICAgICAgdXJsOiAncGFnZS8nICsgaXRlbSArICcuanMnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0aXRsZTogaXRlbSxcbiAgICAgICAgICB1cmw6IGl0ZW1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG59OyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///23\n");

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n/*\n * @Author: remi.zhang\n * @Date: 2018-12-11 14:09:43\n * @Last Modified by: remi.zhang\n * @Last Modified time: 2019-02-26 17:50:48\n */\n\nvar moduleList = exports.moduleList = ['wb-router', 'wb-network', 'wb-event', 'globalEvent',\n// 'wb-location',\n'wb-modal', 'wb-navigator', 'wb-external', 'wb-lottie', 'wb-websocket'];\n\nexports.default = {\n  moduleList: moduleList\n};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvdXRpbHMvbW9kdWxlTGlzdC5qcz80N2JjIl0sIm5hbWVzIjpbIm1vZHVsZUxpc3QiXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7Ozs7Ozs7QUFPTyxJQUFNQSxrQ0FBYSxDQUN4QixXQUR3QixFQUV4QixZQUZ3QixFQUd4QixVQUh3QixFQUl4QixhQUp3QjtBQUt4QjtBQUNBLFVBTndCLEVBT3hCLGNBUHdCLEVBUXhCLGFBUndCLEVBU3hCLFdBVHdCLEVBVXhCLGNBVndCLENBQW5COztrQkFhUTtBQUNiQTtBQURhLEMiLCJmaWxlIjoiMjQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogQEF1dGhvcjogcmVtaS56aGFuZ1xuICogQERhdGU6IDIwMTgtMTItMTEgMTQ6MDk6NDNcbiAqIEBMYXN0IE1vZGlmaWVkIGJ5OiByZW1pLnpoYW5nXG4gKiBATGFzdCBNb2RpZmllZCB0aW1lOiAyMDE5LTAyLTI2IDE3OjUwOjQ4XG4gKi9cblxuZXhwb3J0IGNvbnN0IG1vZHVsZUxpc3QgPSBbXG4gICd3Yi1yb3V0ZXInLFxuICAnd2ItbmV0d29yaycsXG4gICd3Yi1ldmVudCcsXG4gICdnbG9iYWxFdmVudCcsXG4gIC8vICd3Yi1sb2NhdGlvbicsXG4gICd3Yi1tb2RhbCcsXG4gICd3Yi1uYXZpZ2F0b3InLFxuICAnd2ItZXh0ZXJuYWwnLFxuICAnd2ItbG90dGllJyxcbiAgJ3diLXdlYnNvY2tldCcsXG5dXG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgbW9kdWxlTGlzdCxcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///24\n");

/***/ }),
/* 25 */
/***/ (function(module, exports) {

eval("module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;\n  return _c('scroller', {\n    staticClass: [\"wrapper\"]\n  }, _vm._l((_vm.moduleList), function(item, index) {\n    return _c('text', {\n      key: index,\n      staticClass: [\"item\"],\n      on: {\n        \"click\": function($event) {\n          _vm.detail(item)\n        }\n      }\n    }, [_vm._v(\"\\n    \" + _vm._s(item) + \"\\n  \")])\n  }))\n},staticRenderFns: []}\nmodule.exports.render._withStripped = true//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvcGFnZS9tb2R1bGUvQXBwLnZ1ZT9iMThjIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQixtQkFBbUIsYUFBYSwwQkFBMEI7QUFDMUU7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSCxDQUFDO0FBQ0QiLCJmaWxlIjoiMjUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cz17cmVuZGVyOmZ1bmN0aW9uICgpe3ZhciBfdm09dGhpczt2YXIgX2g9X3ZtLiRjcmVhdGVFbGVtZW50O3ZhciBfYz1fdm0uX3NlbGYuX2N8fF9oO1xuICByZXR1cm4gX2MoJ3Njcm9sbGVyJywge1xuICAgIHN0YXRpY0NsYXNzOiBbXCJ3cmFwcGVyXCJdXG4gIH0sIF92bS5fbCgoX3ZtLm1vZHVsZUxpc3QpLCBmdW5jdGlvbihpdGVtLCBpbmRleCkge1xuICAgIHJldHVybiBfYygndGV4dCcsIHtcbiAgICAgIGtleTogaW5kZXgsXG4gICAgICBzdGF0aWNDbGFzczogW1wiaXRlbVwiXSxcbiAgICAgIG9uOiB7XG4gICAgICAgIFwiY2xpY2tcIjogZnVuY3Rpb24oJGV2ZW50KSB7XG4gICAgICAgICAgX3ZtLmRldGFpbChpdGVtKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSwgW192bS5fdihcIlxcbiAgICBcIiArIF92bS5fcyhpdGVtKSArIFwiXFxuICBcIildKVxuICB9KSlcbn0sc3RhdGljUmVuZGVyRm5zOiBbXX1cbm1vZHVsZS5leHBvcnRzLnJlbmRlci5fd2l0aFN0cmlwcGVkID0gdHJ1ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///25\n");

/***/ })
/******/ ]);